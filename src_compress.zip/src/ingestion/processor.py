import os
import sys
import uuid
import json 
import logfire

from qdrant_client import QdrantClient
from qdrant_client.http import models

from src.config.config import settings

from src.retrieval.embeddings import embed_texts, get_embedding_dim

from src.ingestion.loaders.pdf import parse_pdf     
from src.ingestion.loaders.html import parse_html
from src.ingestion.loaders.text import parse_text
from src.ingestion.chunking.splitter import chunk_text

# Local folder where parsed + chunked JSON metadata is saved
PROCESSED_DATA_DIR = "processed_data"

# Lazy Qdrant client — instantiated on first use so a missing env var
# raises a clear error at call time, not silently at import time.
_qdrant_client: QdrantClient | None = None

def _get_qdrant() -> QdrantClient:
    """Return (and lazily create) the shared Qdrant client."""
    global _qdrant_client
    if _qdrant_client is None:
        if not settings.QDRANT_URL:
            raise EnvironmentError("QDRANT_CLUSTER_ENDPOINT is not set in your .env file.")
        _qdrant_client = QdrantClient(
            url=settings.QDRANT_URL,
            api_key=settings.QDRANT_API_KEY,
        )
    return _qdrant_client


def save_processed_locally(data: dict, source_type: str, filename: str) -> str:
    """Save parsed chunk metadata as JSON in processed_data/<source_type>/."""
    folder = os.path.join(PROCESSED_DATA_DIR, source_type)
    os.makedirs(folder, exist_ok=True)
    dest = os.path.join(folder, f"{filename}.json")
    with open(dest, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return dest


def process_file(file_path: str, filename: str, source_type: str):
    """Parse → chunk → save locally → embed → index in Qdrant."""
    with logfire.span("Processing File", file=filename, source=source_type):
        try:
            # 1. Extract text based on file extension
            ext = filename.lower().rsplit(".", 1)[-1]
            if ext == "pdf":
                full_text = parse_pdf(file_path)
            elif ext in ("html", "htm"):
                full_text = parse_html(file_path)
            elif ext in ("txt", "md"):
                full_text = parse_text(file_path)
            elif ext in ("docx", "pptx"):
                from src.ingestion.loaders.office import parse_office
                full_text = parse_office(file_path)
            else:
                logfire.warning(f"Skipping unsupported file type: {filename}")
                return
 
            if not full_text or not full_text.strip():
                logfire.warning(f"No text extracted from {filename} — skipping.")
                return

            # 2. Chunk text
            chunks = chunk_text(full_text)
            if not chunks:
                return

            # 3. Save processed metadata locally
            processed_data = {
                "filename": filename,
                "source_type": source_type,
                "chunks": chunks,
            }
            # Strip extension so the output file is e.g. "report.json" not "report.pdf.json"
            base_name = os.path.splitext(filename)[0]
            local_path = save_processed_locally(processed_data, source_type, base_name)
            logfire.info(f"Saved processed data → {local_path}")

            # 4. Embed and index in Qdrant
            with logfire.span("Vectorizing & Indexing"):
                embeddings = embed_texts(chunks)
                points = [
                    models.PointStruct(
                        id=str(uuid.uuid4()),
                        vector=vector,
                        payload={
                            "text": chunk,
                            "source": filename,
                            "source_type": source_type,
                            "label": "true" if source_type == "true" else "noise",
                        },
                    )
                    for chunk, vector in zip(chunks, embeddings)
                ]

                _get_qdrant().upsert(
                    collection_name=settings.QDRANT_COLLECTION,
                    points=points,
                )
                logfire.info(f"Indexed {len(points)} points to Qdrant from {filename}.")

        except Exception as e:
            logfire.error(f"Failed to process {filename}: {e}")
            raise  # Re-raise so the caller knows this file failed


def process_directory(dir_path: str, source_type: str):
    """Recursively process every file under dir_path (all nested sub-folders included)."""
    with logfire.span("Scanning Directory", path=dir_path, source=source_type):
        all_files = [
            os.path.join(root, filename)
            for root, _dirs, files in os.walk(dir_path)
            for filename in files
        ]
        logfire.info(f"Found {len(all_files)} files (recursive) under {dir_path}.")
        for file_path in all_files:
            filename = os.path.basename(file_path)
            process_file(file_path, filename, source_type)


def run_universal_ingestion(base_dir: str, explicit_source_type: str = None, wipe: bool = False):
    """
    Scan base_dir, map sub-folders to source types, and ingest all documents.
    Pass --wipe to drop and recreate the Qdrant collection before ingestion.
    """
    with logfire.span("Universal Ingestion Started", base_directory=base_dir):

        # Wipe collection if requested
        if wipe:
            with logfire.span("Wiping Collection"):
                if _get_qdrant().collection_exists(settings.QDRANT_COLLECTION):
                    _get_qdrant().delete_collection(settings.QDRANT_COLLECTION)
                    logfire.info(f"Collection '{settings.QDRANT_COLLECTION}' deleted.")

        # Recreate collection — dimension resolved at runtime after embedding model probe
        if not _get_qdrant().collection_exists(settings.QDRANT_COLLECTION):
            dim = get_embedding_dim()
            _get_qdrant().create_collection(
                collection_name=settings.QDRANT_COLLECTION,
                vectors_config=models.VectorParams(
                    size=dim,
                    distance=models.Distance.COSINE,
                ),
            )
            logfire.info(
                f"Created collection '{settings.QDRANT_COLLECTION}' "
                f"({dim}-dim, Cosine)."
            )

        # Route to sub-folders or treat the whole dir as one source
        subdirs = [
            d for d in os.listdir(base_dir)
            if os.path.isdir(os.path.join(base_dir, d))
        ]

        if not subdirs:
            if explicit_source_type:
                source_type = explicit_source_type
            else:
                base_name = os.path.basename(os.path.normpath(base_dir)).lower()
                source_type = (
                    "true" if "true" in base_name
                    else "noisy" if "noisy" in base_name
                    else "general"
                )
            logfire.info(f"No sub-folders found — processing '{base_dir}' as '{source_type}'.")
            process_directory(base_dir, source_type)
        else:
            for subdir in subdirs:
                source_type = (
                    "true" if "true" in subdir.lower()
                    else "noisy" if "noisy" in subdir.lower()
                    else subdir
                )
                process_directory(os.path.join(base_dir, subdir), source_type)


if __name__ == "__main__":
    # Usage:
    #   python -m src.ingestion.processor DATA --wipe
    #   python -m src.ingestion.processor DATA/true_data true

    # Configure logfire only when running this file directly, not on import
    logfire.configure(service_name="enterprise-ingestion-service")

    wipe_requested = "--wipe" in sys.argv
    clean_args = [a for a in sys.argv if a != "--wipe"]

    target_dir = clean_args[1] if len(clean_args) > 1 else "DATA"
    explicit_type = clean_args[2] if len(clean_args) > 2 else None

    if not os.path.exists(target_dir):
        print(f"Error: path '{target_dir}' does not exist.")
        sys.exit(1)

    run_universal_ingestion(target_dir, explicit_source_type=explicit_type, wipe=wipe_requested)
    logfire.info("Ingestion job completed.")

